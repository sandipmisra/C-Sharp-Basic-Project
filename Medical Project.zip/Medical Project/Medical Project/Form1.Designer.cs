﻿namespace Medical_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1_Live = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_Save = new System.Windows.Forms.Button();
            this.button_Capture = new System.Windows.Forms.Button();
            this.button_Start = new System.Windows.Forms.Button();
            this.comboBox_CamList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox3_pic = new System.Windows.Forms.PictureBox();
            this.pictureBox2_pic = new System.Windows.Forms.PictureBox();
            this.pictureBox1_pic = new System.Windows.Forms.PictureBox();
            this.pictureBox4_pic = new System.Windows.Forms.PictureBox();
            this.button1_Choose = new System.Windows.Forms.Button();
            this.button2_Choose = new System.Windows.Forms.Button();
            this.button3_Choose = new System.Windows.Forms.Button();
            this.button4_Choose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_Live)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1_Live
            // 
            this.pictureBox1_Live.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1_Live.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.pictureBox1_Live.Location = new System.Drawing.Point(26, 50);
            this.pictureBox1_Live.Name = "pictureBox1_Live";
            this.pictureBox1_Live.Size = new System.Drawing.Size(533, 362);
            this.pictureBox1_Live.TabIndex = 1;
            this.pictureBox1_Live.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox2.Location = new System.Drawing.Point(591, 48);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(556, 364);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // button_Save
            // 
            this.button_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Save.Location = new System.Drawing.Point(834, 8);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(132, 32);
            this.button_Save.TabIndex = 5;
            this.button_Save.Text = "Save Image";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // button_Capture
            // 
            this.button_Capture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Capture.Location = new System.Drawing.Point(592, 12);
            this.button_Capture.Name = "button_Capture";
            this.button_Capture.Size = new System.Drawing.Size(136, 32);
            this.button_Capture.TabIndex = 6;
            this.button_Capture.Text = "Capture Image";
            this.button_Capture.UseVisualStyleBackColor = true;
            this.button_Capture.Click += new System.EventHandler(this.button_Capture_Click);
            // 
            // button_Start
            // 
            this.button_Start.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Start.Location = new System.Drawing.Point(444, 10);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(115, 32);
            this.button_Start.TabIndex = 7;
            this.button_Start.Text = "Start";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click);
            // 
            // comboBox_CamList
            // 
            this.comboBox_CamList.FormattingEnabled = true;
            this.comboBox_CamList.Location = new System.Drawing.Point(120, 13);
            this.comboBox_CamList.Name = "comboBox_CamList";
            this.comboBox_CamList.Size = new System.Drawing.Size(256, 28);
            this.comboBox_CamList.TabIndex = 8;
            this.comboBox_CamList.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Camera Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Live Camera";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(593, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Capture Image";
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(1029, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 33);
            this.button2.TabIndex = 17;
            this.button2.Text = "Close App";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(512, 535);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 20;
            // 
            // pictureBox3_pic
            // 
            this.pictureBox3_pic.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox3_pic.Location = new System.Drawing.Point(630, 418);
            this.pictureBox3_pic.Name = "pictureBox3_pic";
            this.pictureBox3_pic.Size = new System.Drawing.Size(276, 215);
            this.pictureBox3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3_pic.TabIndex = 0;
            this.pictureBox3_pic.TabStop = false;
            // 
            // pictureBox2_pic
            // 
            this.pictureBox2_pic.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox2_pic.Location = new System.Drawing.Point(343, 418);
            this.pictureBox2_pic.Name = "pictureBox2_pic";
            this.pictureBox2_pic.Size = new System.Drawing.Size(281, 215);
            this.pictureBox2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2_pic.TabIndex = 1;
            this.pictureBox2_pic.TabStop = false;
            // 
            // pictureBox1_pic
            // 
            this.pictureBox1_pic.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox1_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1_pic.Location = new System.Drawing.Point(51, 418);
            this.pictureBox1_pic.Name = "pictureBox1_pic";
            this.pictureBox1_pic.Size = new System.Drawing.Size(286, 215);
            this.pictureBox1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_pic.TabIndex = 2;
            this.pictureBox1_pic.TabStop = false;
            // 
            // pictureBox4_pic
            // 
            this.pictureBox4_pic.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox4_pic.Location = new System.Drawing.Point(912, 418);
            this.pictureBox4_pic.Name = "pictureBox4_pic";
            this.pictureBox4_pic.Size = new System.Drawing.Size(276, 215);
            this.pictureBox4_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4_pic.TabIndex = 21;
            this.pictureBox4_pic.TabStop = false;
            this.pictureBox4_pic.Click += new System.EventHandler(this.pictureBox4_pic_Click);
            // 
            // button1_Choose
            // 
            this.button1_Choose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1_Choose.Location = new System.Drawing.Point(24, 639);
            this.button1_Choose.Name = "button1_Choose";
            this.button1_Choose.Size = new System.Drawing.Size(136, 32);
            this.button1_Choose.TabIndex = 22;
            this.button1_Choose.Text = "Choose Image";
            this.button1_Choose.UseVisualStyleBackColor = true;
            this.button1_Choose.Click += new System.EventHandler(this.button1_Choose_Click);
            // 
            // button2_Choose
            // 
            this.button2_Choose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2_Choose.Location = new System.Drawing.Point(312, 639);
            this.button2_Choose.Name = "button2_Choose";
            this.button2_Choose.Size = new System.Drawing.Size(136, 32);
            this.button2_Choose.TabIndex = 23;
            this.button2_Choose.Text = "Choose Image";
            this.button2_Choose.UseVisualStyleBackColor = true;
            this.button2_Choose.Click += new System.EventHandler(this.button2_Choose_Click);
            // 
            // button3_Choose
            // 
            this.button3_Choose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3_Choose.Location = new System.Drawing.Point(590, 639);
            this.button3_Choose.Name = "button3_Choose";
            this.button3_Choose.Size = new System.Drawing.Size(136, 32);
            this.button3_Choose.TabIndex = 24;
            this.button3_Choose.Text = "Choose Image";
            this.button3_Choose.UseVisualStyleBackColor = true;
            this.button3_Choose.Click += new System.EventHandler(this.button3_Choose_Click);
            // 
            // button4_Choose
            // 
            this.button4_Choose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4_Choose.Location = new System.Drawing.Point(876, 639);
            this.button4_Choose.Name = "button4_Choose";
            this.button4_Choose.Size = new System.Drawing.Size(136, 32);
            this.button4_Choose.TabIndex = 25;
            this.button4_Choose.Text = "Choose Image";
            this.button4_Choose.UseVisualStyleBackColor = true;
            this.button4_Choose.Click += new System.EventHandler(this.button4_Choose_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1164, 710);
            this.Controls.Add(this.button4_Choose);
            this.Controls.Add(this.button3_Choose);
            this.Controls.Add(this.button2_Choose);
            this.Controls.Add(this.button1_Choose);
            this.Controls.Add(this.pictureBox4_pic);
            this.Controls.Add(this.pictureBox1_pic);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox3_pic);
            this.Controls.Add(this.pictureBox2_pic);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_CamList);
            this.Controls.Add(this.button_Start);
            this.Controls.Add(this.button_Capture);
            this.Controls.Add(this.button_Save);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1_Live);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Medical Application";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_Live)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_pic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1_Live;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Button button_Capture;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.ComboBox comboBox_CamList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1_pic;
        private System.Windows.Forms.PictureBox pictureBox2_pic;
        private System.Windows.Forms.PictureBox pictureBox3_pic;
        private System.Windows.Forms.PictureBox pictureBox4_pic;
        private System.Windows.Forms.Button button1_Choose;
        private System.Windows.Forms.Button button2_Choose;
        private System.Windows.Forms.Button button3_Choose;
        private System.Windows.Forms.Button button4_Choose;
    }
}

