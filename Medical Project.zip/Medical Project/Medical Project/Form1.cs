﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Drawing.Imaging;


namespace Medical_Project
{
    public partial class Form1 : Form
    {
        private FilterInfoCollection CaptureDevice;
        private VideoCaptureDevice VedioDevice;

        public Form1()
        {
            InitializeComponent();
        }

        void getCamlist()
        {
            CaptureDevice = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach(FilterInfo Devices in CaptureDevice)
            {
                comboBox_CamList.Items.Add(Devices.Name);
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // int w = Screen.PrimaryScreen.Bounds.Width;
           // int h = Screen.PrimaryScreen.Bounds.Height;
           // this.Location = new Point(0, 0);
          //  this.Size = new Size(w, h);

            getCamlist();
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            VedioDevice = new VideoCaptureDevice (CaptureDevice[comboBox_CamList.SelectedIndex].MonikerString);
            VedioDevice.NewFrame += new NewFrameEventHandler(NewVedioFrame);
            VedioDevice.Start();

        }

        private void NewVedioFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pictureBox1_Live.Image = (Bitmap)eventArgs.Frame.Clone();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button_Capture_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = (Bitmap)pictureBox1_Live.Image.Clone();

        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "Save Image As";
            sfd.Filter = " Image File (*.jpg, *.bmp, *.png)| *.jpg;*.bmp;*.png";
            ImageFormat imageFormat = ImageFormat.Png;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string ext = System.IO.Path.GetExtension(sfd.FileName);

                switch(ext)
                    {
                    case ".jpg":
                        imageFormat = ImageFormat.Jpeg;
                        break;
                    case ".bmp":
                        imageFormat = ImageFormat.Bmp;
                        break;

                    }
                pictureBox2.Image.Save(sfd.FileName, imageFormat);
            }
        }

      /*  private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Your Images";
            ofd.Multiselect = true;
            ofd.Filter = "JPG|*.jpg|JPGE|*.jpge|GIF|*.gif|PNG|*.png";
            DialogResult dr = ofd.ShowDialog();
            if(dr == System.Windows.Forms.DialogResult.OK)
            {
                string [] files = ofd.FileNames;
                int x = 20;
                int y = 20;
                int maxHight = -1;


                foreach (string img in files)
                {
                    PictureBox pic = new PictureBox();
                    pic.Image = Image.FromFile(img);
                    pic.Location = new Point(x, y);
                    pic.SizeMode = PictureBoxSizeMode.StretchImage;
                    x += pic.Width + 10;
                    maxHight = Math.Max(pic.Height, maxHight);
                    if (x > this.ClientSize.Width-100)
                    {
                        x = 20;
                        y += maxHight + 10;

                    }
                    this.panel1.Controls.Add(pic);
                }
            }
        }*/

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

       

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Choose_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1_pic.Image = Image.FromFile(ofd.FileName);
            }
            else
            {
                MessageBox.Show("Please Select Proper Image");
            }
        }

        private void button3_Choose_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox3_pic.Image = Image.FromFile(ofd.FileName);
            }
            else
            {
                MessageBox.Show("Please Select Proper Image");
            }
        }

        private void button2_Choose_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox2_pic.Image = Image.FromFile(ofd.FileName);
            }
            else
            {
                MessageBox.Show("Please Select Proper Image");
            }
        }

        private void button4_Choose_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox4_pic.Image = Image.FromFile(ofd.FileName);
            }
            else
            {
                MessageBox.Show("Please Select Proper Image");
            }
        }

        private void pictureBox4_pic_Click(object sender, EventArgs e)
        {
            
            
        }
    }
}
